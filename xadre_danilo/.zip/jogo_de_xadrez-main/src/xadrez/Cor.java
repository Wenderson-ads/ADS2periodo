package xadrez;

public enum Cor {

	BRANCO,
	PRETO;
}
