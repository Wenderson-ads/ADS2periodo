package xadrez;

import tabuleiro.ExcecaoTabuleiro;

public class ExcecaoXadrez extends ExcecaoTabuleiro{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public ExcecaoXadrez(String message) {
		super(message);
	}

	
}
